import express from 'express'
import { viewContact } from "../controller/common_controller.js";
const commonRoute=express.Router()
commonRoute.get('/allContact',viewContact)
export default commonRoute
