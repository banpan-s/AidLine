import express from 'express'
import commonRoute from './router/common_router.js'
const serverApp=express()
const PORT_NUMBER=3000

serverApp.use(express.json())  //middle ware
serverApp.use("/",commonRoute)

serverApp.listen(PORT_NUMBER,()=>{
    console.log(`server is listening on http://localhost:${PORT_NUMBER}`)
})