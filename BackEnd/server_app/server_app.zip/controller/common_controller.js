export const viewContact=(request,response)=>{
    response.send("<h1>All contacts are seen here <h1/>")
}
