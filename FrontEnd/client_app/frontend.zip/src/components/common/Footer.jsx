import '../../css/Custom_style.css'


const Footer = () => {
    return(
        <>
        <footer className='box'>
            <h2></h2>
            <h3>Created by Bheem</h3>
            <p>Copyright 2022</p>
        </footer>
        </>
    )
}
export default Footer