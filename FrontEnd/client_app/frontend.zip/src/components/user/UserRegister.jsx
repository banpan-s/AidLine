import React, { useState } from "react";
import axios from 'axios'
import { useNavigate } from "react-router-dom";
import Header from "../common/Header";
import Footer from "../common/Footer";

function UserRegister() {
  const navigate = useNavigate();
  const URL = "http://localhost:3000/user/addUser";

  // State to store user input data
  const [userData, setUserData] = useState({
    email: "",
    password: "",
    name: "",
    phone: "",
    gender: "",
    city: "",
    address: "",
  });
  
  // State to store user uploaded profile picture
  const [userPic, setUserPic] = useState(null);

  // Function to handle input changes
  const fetchData = (e) => {
    const { name, value, type, files } = e.target;
    
    if (type === "file") {
      console.log(files[0]);
      setUserPic(files[0]); // Store file object in state
    } else {
      setUserData({ ...userData, [name]: value }); // Update user data state
    }
  };

  // Function to handle form submission
  const submitData = async (e) => {
    e.preventDefault(); // Prevent page reload
    alert("in submit");
    console.log(userPic);
    
    // Creating FormData object to send data including file
    const formData = new FormData();
    formData.append("email", userData.email);
    formData.append("password", userData.password);
    formData.append("name", userData.name);
    formData.append("phone", userData.phone);
    formData.append("gender", userData.gender || "Not specified"); // Ensure gender is sent
    formData.append("city", userData.city);
    formData.append("address", userData.address);
    
    // Only append profile picture if it's selected
    if (userPic) {
      formData.append("pic", userPic);
    }

    try {
      // Sending data to backend API
      const response = await axios.post(URL, formData);
      console.log(response);
      console.log(formData);
      alert(response.data);
      alert("Registration done successfully");
      
      // Reset form fields after successful submission
      setUserData({
        email: "",
        password: "",
        name: "",
        phone: "",
        gender: "",
        city: "",
        address: "",
      });
      setUserPic(null);
      
      // Navigate to user login page
      navigate("/userlogin");
    } catch (err) {
      console.log(err.message);
    }
  };

  return (
    <>
      {/* Header Component */}
      <Header/>
      
      <div className="w-100 text-center">
        <h1>User Registration</h1>
      </div>
      
      <div className="row justify-content-center align-items-center h-50 w-100">
        <div className="col-md-6 pt-2">
          {/* User Registration Form */}
          <form onSubmit={submitData}>
            
            {/* Email Input Field */}
            <div className="input-group mb-3">
              <span className="input-group-text"><i className="fas fa-envelope-square"></i></span>
              <div className="form-floating">
                <input
                  type="email"
                  className="form-control"
                  id="email"
                  placeholder="email"
                  name="email"
                  value={userData.email}
                  onChange={fetchData}
                />
                <label htmlFor="email">Email</label>
              </div>
            </div>

            {/* Password Input Field */}
            <div className="input-group mb-3">
              <span className="input-group-text"><i className="fas fa-key"></i></span>
              <div className="form-floating">
                <input
                  type="password"
                  className="form-control"
                  id="password"
                  placeholder="password"
                  name="password"
                  value={userData.password}
                  onChange={fetchData}
                />
                <label htmlFor="password">Password</label>
              </div>
            </div>

            {/* Name Input Field */}
            <div className="input-group mb-3">
              <span className="input-group-text"><i className="fas fa-user-circle"></i></span>
              <div className="form-floating">
                <input
                  type="text"
                  className="form-control"
                  id="name"
                  placeholder="username"
                  name="name"
                  value={userData.name}
                  onChange={fetchData}
                />
                <label htmlFor="name">Name</label>
              </div>
            </div>

            {/* Phone Input Field */}
            <div className="input-group mb-3">
              <span className="input-group-text"><i className="fas fa-phone"></i></span>
              <div className="form-floating">
                <input
                  type="tel"
                  className="form-control"
                  id="phone"
                  placeholder="phone"
                  name="phone"
                  value={userData.phone}
                  onChange={fetchData}
                />
                <label htmlFor="phone">Phone</label>
              </div>
            </div>

            {/* Address Input Field */}
            <div className="input-group mb-3">
              <span className="input-group-text"><i className="fas fa-map"></i></span>
              <div className="form-floating">
                <textarea
                  className="form-control"
                  id="address"
                  placeholder="address"
                  name="address"
                  value={userData.address}
                  onChange={fetchData}
                />
                <label htmlFor="address">Address</label>
              </div>
            </div>

            {/* File Input for Profile Picture */}
            <div className="input-group mb-3">
              <span className="input-group-text"><i className="fas fa-user"></i></span>
              <div className="form-floating">
                <input
                  type="file"
                  name="pic"
                  className="form-control"
                  onChange={fetchData}
                />
              </div>
            </div>

            {/* Submit Button */}
            <div className="text-center">
              <button className="btn btn-primary">Submit</button>
            </div>
          </form>
        </div>
      </div>
      
      {/* Footer Component */}
      <Footer/>
    </>
  );
}

export default UserRegister;
